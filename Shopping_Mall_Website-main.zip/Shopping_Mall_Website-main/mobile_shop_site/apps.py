from django.apps import AppConfig


class MobileShopSiteConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mobile_shop_site'
