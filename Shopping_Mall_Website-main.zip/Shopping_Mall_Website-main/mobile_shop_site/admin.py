from django.contrib import admin
from .models import Mobile,Other_parts,RepairCost

# Register your models here.
admin.site.register(Mobile)
admin.site.register(Other_parts)
admin.site.register(RepairCost)

